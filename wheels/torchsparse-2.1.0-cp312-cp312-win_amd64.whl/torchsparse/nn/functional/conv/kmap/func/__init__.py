from .hashmap import *
from .hashmap_on_the_fly import *
